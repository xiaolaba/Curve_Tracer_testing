ReadMe File For CT2 " Curve Tracer II"

Warning
This computer program is protected by copyright law and international treaties. Unauthorized reproduction or distribution of this program, or any portion of it,  may result in severe criminal and civil penalties, and will be prosecuted to the maximum extent possible under law. You are allowed to distribute CT2 on the internet only if you distribute it in it's original package. You must have the author's written permission to distribute CT2 on CD-ROM or in any other media other than the internet.  E-Mail is acceptable as a written permission.

Disclaimer

This product is provided "as is" without any warranty of any kind. To the maximum extent permitted by applicable law, the author further disclaims all warranties, including without limitation any implied or stated warranties of merchantability, fitness for a particular purpose, and no infringement. The entire risk arising out of the use or performance of this product and documentation remains with recipient. To the maximum extent permitted by applicable law, in no event
 shall the author or his suppliers be liable for any consequential, incidental, direct, indirect, special, punitive, recursive, or other damages whatsoever(including, without limitation, damages for loss of business profits, business interruption, loss of business information, personal injury, disruption of family life, or other pecuniary loss) arising out of this agreement or the use of or inability to use the product, even if the author has been advised of the possibility of such damages. Because some states/jurisdictions do not allow the exclusion or limitation of liability for consequential or incidental damages, the above limitation may not apply to the recipient.

Curve Tracer II
This system was designed to obtain and display accurate xy plots of electrical components such as diodes, LEDs, resistors, transistors, and the like on your computer.  It is designed to use the existing sound card of the computer.  There is no need to open the computer case.  Access is only required to the line input/output  jacks of the sound card, usually found on the rear panel of the computer. An external hardware circuit is needed.  The software processes the sound card input and displays it. 

System Requirements
You need a 200 MHz computer with at least 32 MB of RAM,   the Windows 98SE or XP operating system and a full duplex sound card like the Sound Blaster Live.  

Sound Card Considerations

A low distortion, low noise full duplex sound card is desirable. The economical Sound Blaster Live, Value Edition fills the bill nicely and probably many others will too.  But since I cannot test them all, I will restrict my attention to this one. Referring to Figure 3, we see that A1 is the line output amplifier, and A2 and A3 are the right and left channel line inputs of the sound card. The mixer control in your Windows software controls the gains of these amps. The level of the line output signal is controlled in the PLAY section of the mixer via the Wave  and Spkr sliders. So to control the amplitude of the sine wave output, just adjust the sliders.

The gain of the line input amps A2 and A3 are controlled in the RECORD section of the mixer by the Line slider. They will saturate if the input voltage is too high, regardless of the RECORD setting in the mixer. On the SB this occurs at 820 mV. Fortunately this is easy to detect as the captured signal will flat top. Since, at saturation, the linear gain of the amplifier is lost we may also see a fictitious current bump in the DUT current trace at the extreme voltage limits. A real time oscilloscope function is provided in the software to help monitor for this condition. So, if you see a current bump in the I-V trace when there is no DUT in place, it is likely caused by an amplifier saturating. Just back off a little with the PLAY output signal or just ignore it. 

A note is in order on earlier Sound Blaster sound cards such as the SB16 and AWE 32 since there are so many of these still around. Unfortunately they do not provide true full duplex operation and are noisy. The same may be said of SB compatible cards, so be wary. For example (with latest drivers) the SB AWE32 only can only play unsigned 8 bits and record signed16 bits at once. It also has a built-in amplifier that may overdrive the interface circuit. My advice is not to use any of these cards.  

External Hardware Requirement.
You need to build a simple circuit to generate the voltage and current signals for the device under test (DUT) and present them to the sound card.  Such a circuit is shown in the included file CT2Fig3.wmf which is a windows metafile that most programs will read.   Stereo cables are used to connect the circuit to the sound card line input/output jacks.

System Setup And Calibration

First make sure the circuit is powered and connected to the sound card line inputs as shown in Figure 3. The mixer that came with your sound card or the one that came with Windows � needs to be checked as you may have changed its settings. When you start the program, a little notice comes on the screen to remind you to do this. Basically you want to set the output level, input gain and stereo balance. The details on how to do this will obviously vary from system to system. Here is how its done with the SB Live. 

In the mixer PLAY section, enable  Wave and Spkr, set the sliders to max and mute all others (including Line to avoid audio feedback). In the RECORD section, enable Line, set it to max and mute all others. Set the stereo balance to center for all controls. These settings are important.  For example, if you forget to mute Line in the PLAY section there will be errors.

Calibration needs to be performed only once since parameters are saved in a file CTinit upon exit.  Follow these steps closely so good accuracy can be achieved. First, remove the DUT.  Next, set the jumper J1 on the circuit so that the step voltage is applied to Rm.    Run the program. Click �Start� and wait for the TrgRdy LED to change from Green to Red.  Now create the step voltage by closing switch SW1 on the circuit.   Upon capture of the step voltage data, the TrgRdy LED will revert to Green.  With SW1 still closed measure the step voltage at TP1 with a good voltmeter, preferably a digital type, and write it down.  View the data captured by the program using the left cursor in dual mode.  You should see a large step voltage on L channel (Green) and small voltage on (R-L) channel (Blue). See Figure 5 for example.  The data should start out clean without much noise.  If there is a lot of noise at the start of capture (probably due to SW1 bounce), repeat the capture until clean.

The captured data is used to calibrate the program.  Click on the Calibrate button to begin.  Change the values shown in the Calibrate box as needed.   All calibration is done on the originally captured step voltage.  It does not need to be recaptured  each time. Use the left cursor (left mouse button) to measure the data on the L and (R-L) channels as needed.

Adjust the Channel Balance value until the (R-L) channel is close to zero. This is essentially the voltage across Rm, which should be zero since the current in it is zero because the DUT is not present.

Adjust the Compensation value until there is no droop or rise of the step voltage of the L channel. After its initial rise the step should flatten out to be a straight horizontal  line across the window of the scope.  If it is over corrected the line will rise while if under corrected it will decline. See Figure 5 for an example of over, under and proper compensation. Make corrections in very small amounts. Use the cursor to verify it is straight by moving it across the waveform while looking at the readout.

The Volts per bit calibration is done on the L channel of the sound card.  Use the left cursor and measure the voltage of the L channel.   Adjust this value until the cursor value is close to the value you measured with the voltmeter earlier. Each time you click the �Apply� button in  the Calibration box , these values are applied to the captured step data. You will immediately see the results on the screen. Repeat these steps until the best calibration is achieved.

Other Calibration Box Values

The Trigger Level controls the voltage level at which the beginning of the input signal is captured. If you get false captures, you can increase this value.  If the value is too high, you will miss the leading edge of the captured waveform.  If it is too low, you will get false triggers due to noise. 

The reason for the Invert Input box is that some sound cards invert the signal.  The SB Live inverts the data, so this box needs to be checked to correct the input polarity.   To determine if your sound card inverts the data, look at the step waveform of the L channel.  It should start out positive for a positive input such as provided by the hardware circuit.   If not, you need to check the box to invert the data.   

Enter the value of the current measuring resistor in ohms in the Rm box.  The cursor readout will display device current based on this value using Ohm's law.

Here are values for my SB Live card. Channel Bal:  0.9551, Compensation: +10, Volts Per Bit:  0.00033982, Trigger Level:  200, Rm: 98.8, and Invert: Box checked.

Sample Traces.

Saved files are designated as cct files.  There are several samples included here such a zener diode, transitor and lambda diode.  They may be loaded into the program and displayed.  This will give you an idea of what to expect. with your own curve tracing.

File Missing Messages.

1.  If you get the message "Required DLL file MSVBVM60.DLL was not found" when you try to run the program  you will
 need to obtain it and install it on your system. It is available from Microsoft and other sites on the web.  It is usually
 available as Visual Basic 6.0 SP5: Run-Time Redistribution Pack (VBRun60sp5.exe).  It may be included with this
 package.  If not,  you need to download it.

VBRun60sp5.exe is a self-extracting executable file that installs versions of the Microsoft Visual Basic run-time files
 required by all applications created with Visual Basic 6.0. The files include the fixes shipped with Visual Studio 6.0
 Service Pack 5. 

Version - sp5  Release Date - 28 Feb 2001   Estimated Download Size/Time @28.8 - 1,045 kb / 6min 

2.  If you get the message "Component 'COMDLG32.OCX' or one of its dependencies is not correctly  registered: a file
is missing or invalid." when you try to run the program, you will need to install it on your system.  This error has been reported with all versions of Windows. The needed file is usually included with many Windows programs, but if you get this message it is not on your system.  Check to see if a copy is included with this package.  If not, you need to download it and install it as shown below.

- Obtain a copy of COMDLG32.OCX from Microsoft or other  web site via download .
- Copy it into the \Windows\System32 directory. 
- Open the Windows run dialog box using "Start | Run..." and enter "Regsvr32 c:\windows\system32\comdlg32.ocx" 
   to register the DLL. 

Copyright 2002-2006 George R. Steber.  All Rights Reserved. 
